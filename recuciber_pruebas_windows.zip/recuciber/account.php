<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>PowerSupps | Mi cuenta</title>
  <link rel="stylesheet" href="css/styles.css" />
</head>
<body>
<?php
  session_start();
  include_once 'persistence/MySQLPDO.class.php';

  if (!isset($_SESSION['iduser'])) {
    header("Location: login.php");
    exit;
  }

  MySQLPDO::connect();
  $usuario = MySQLPDO::getUsuarioById($_SESSION['iduser']);

  if ($usuario === null) {
    // si el id no existe (raro), cerramos sesión
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
  }
?>
<header class="header">
  <a class="brand" href="index.php">
    <span class="brand__logo">PS</span>
    <span class="brand__text">
      <strong>PowerSupps</strong>
      <small>Mi cuenta</small>
    </span>
  </a>

  <div class="header__actions">
    <a class="btn btn--ghost" href="index.php">← Volver a la tienda</a>
  </div>
</header>

<main class="authPage">
  <section class="authCard" style="width:35%;">
    <h2>Mi cuenta</h2>
    <p class="muted">Información del usuario</p>

    <div class="summaryBox">
      <div class="summaryItem">
        <span>Nombre</span>
        <span><?php echo htmlspecialchars($usuario['nombre']); ?></span>
      </div>

      <div class="summaryItem">
        <span>Apellidos</span>
        <span><?php echo htmlspecialchars($usuario['apellidos']); ?></span>
      </div>

      <div class="summaryItem">
        <span>Usuario</span>
        <span><?php echo htmlspecialchars($usuario['user']); ?></span>
      </div>

      <div class="summaryItem">
        <span>Email</span>
        <span><?php echo htmlspecialchars($usuario['email']); ?></span>
      </div>
      <div class="summaryItem">
        <span><a href="rec_pass.php?user=<?php echo urlencode($usuario['user']); ?>">
          Cambiar contraseña
        </a>
        </span>
      </div>
    </div>

    <div style="display:flex; gap:10px; margin-top:14px; flex-wrap:wrap;">
      <a class="btn btn--primary" href="logout.php">Cerrar sesión</a>
      <a class="btn btn--ghost" href="index.php">Volver</a>
    </div>
  </section>
</main>

</body>
</html>