<?php
session_start();
unset($_SESSION["carrito"]);
header("Location: cart.php");
exit;
?>