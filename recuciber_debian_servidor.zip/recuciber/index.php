<?php
session_start();
include_once 'persistence/MySQLPDO.class.php';
MySQLPDO::connect();

$cat = $_GET["cat"] ?? "Todas";

if ($cat === "Todas") {
  $productos = MySQLPDO::select("SELECT * FROM producto ORDER BY id DESC", []);
} else {
  $productos = MySQLPDO::select("SELECT * FROM producto WHERE categoria = ? ORDER BY id DESC", [$cat]);
}

// carrito contador
$cartCount = 0;
if (isset($_SESSION["carrito"]) && is_array($_SESSION["carrito"])) {
  foreach ($_SESSION["carrito"] as $id => $qty) $cartCount += (int)$qty;
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>PowerSupps | Tienda</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="header">
  <a class="brand" href="index.php">
    <span class="brand__logo">PS</span>
    <span class="brand__text">
      <strong>PowerSupps</strong>
      <small>Proteína · Creatina · Rendimiento</small>
    </span>
  </a>

  <div class="header__actions">
    <?php if (!isset($_SESSION["usuario"])): ?>
      <a class="btn btn--primary" href="login.php">Login</a>
    <?php else: ?>
      <?php if ($_SESSION["usuario"]["rol"] === "admin"): ?>
        <a class="btn btn--ghost" href="admin_products.php">Admin</a>
      <?php endif; ?>
      <a class="userBtn" href="account.php" title="Mi cuenta">👤</a>
    <?php endif; ?>

    <a class="btn btn--ghost" href="cart.php">🛒 <span class="badge"><?= $cartCount ?></span></a>
  </div>
</header>

<main class="container section">
  <div class="section__head">
    <h2>Productos</h2>
    <p>Selecciona tus suplementos y añade al carrito.</p>
  </div>

  <form method="get" class="filters">
    <div class="filters__group">
      <label>Categoría</label>
      <select name="cat" onchange="this.form.submit()">
        <?php
          $cats = ["Todas","Proteína","Creatina","Pre-entreno","Salud"];
          foreach($cats as $c){
            $sel = ($cat === $c) ? "selected" : "";
            echo "<option $sel value='".htmlspecialchars($c,ENT_QUOTES)."'>$c</option>";
          }
        ?>
      </select>
    </div>

    <div class="filters__note">Consejo: añade productos al carrito y pulsa “Finalizar compra”.</div>
  </form>

  <div class="grid">
    <?php foreach($productos as $p): ?>
      <div class="card">
        <div class="card__img" style="padding:0;">
          <img src="<?= htmlspecialchars($p["imagen"]) ?>" alt="<?= htmlspecialchars($p["nombre"]) ?>"
               style="width:100%;height:100%;object-fit:cover;display:block;">
        </div>
        <div class="card__body">
          <h3><?= htmlspecialchars($p["nombre"]) ?></h3>
          <p><?= htmlspecialchars($p["descripcion"]) ?></p>
          <div class="muted tiny">Categoría: <strong><?= htmlspecialchars($p["categoria"]) ?></strong></div>
        </div>
        <div class="card__foot">
          <div class="price"><?= htmlspecialchars($p["precio"]) ?>€</div>
          <form method="post" action="cart_add.php" style="margin-left:auto;display:flex;gap:10px;">
            <input type="hidden" name="id" value="<?= (int)$p["id"] ?>">
            <input class="qty" type="number" name="qty" value="1" min="1">
            <button class="btn btn--primary" type="submit">Añadir</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</main>

</body>
</html>
