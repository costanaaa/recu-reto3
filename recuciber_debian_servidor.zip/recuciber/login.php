<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>PowerSupps | Login</title>
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="css/login.css" />
</head>
<body>
  <?php
    session_start();
  ?>
  <header class="header">
    <a class="brand" href="index.php">
      <span class="brand__logo">PS</span>
      <span class="brand__text">
        <strong>PowerSupps</strong>
        <small>Login</small>
      </span>
    </a>

    <div class="header__actions">
      <a class="btn btn--ghost" href="index.php">← Volver a la tienda</a>
    </div>
  </header>
  <?php
    include_once 'entity/Usuario.class.php';
    include_once 'persistence/MySQLPDO.class.php';
    if(isset($_POST['btn_login'])){
      $email = $_POST['email'];
      $password = $_POST['password'];

      $objetoUsuario = new Usuario();
      $objetoUsuario->setEmail($email);
      $objetoUsuario->setPass($password);
      MySQLPDO::connect();
      $objetoUsuario = MySQLPDO::loginUsuario($objetoUsuario);
      if($objetoUsuario != null){
          $_SESSION["usuario"] = [
            "id" => $objetoUsuario->getId(),
            "user" => $objetoUsuario->getUser(),
            "rol" => $objetoUsuario->getRol(),
          ];

          echo '<script>
              alert("Bienvenido ' , $objetoUsuario->getUser() , '");
              window.location.href = "index.php";
          </script>';
      } else {
        echo '<script language="javascript">alert ("ERROR: El usuario o la contraseña no coinciden")</script>';
      }
    }
  ?>
  <main class="authPage">
    <section class="authCard">
      <h2>Login</h2>
      <p class="muted">Accede para guardar tu carrito (demo).</p>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" id="loginForm" class="form authForm">
        <table>
        <tr>
          <td><p>Email:</p></td>
          <td>
            <input type="email" name="email" required placeholder="correo@dominio.com">
          </td>
        </tr>
        <tr>
          <td><p>Contrase&ntilde;a:</p></td>
          <td>
            <input type="password" name="password" required minlength="6" placeholder="••••••••">
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <input type="submit" value="ENTRAR" name="btn_login">
          </td>
        </tr>
        <tr>
          <td colspan="2">
            ¿No tienes cuenta? <a href="register.php">Reg&iacute;strate aqu&iacute;</a>
          </td>
        </tr>
      </table>
      </form>
    </section>
  </main>
</body>
</html>
