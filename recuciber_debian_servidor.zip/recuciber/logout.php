<?php
session_start();
// Vaciar todas las variables de sesión
session_unset();
// Destruir la sesión
session_destroy();
// Redirigir a la tienda (o login)
header("Location: index.php");
exit;
?>