const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const pass = document.getElementById("pass").value;

  if (!email || !pass) return;

  // Demo: si no existe user, lo crea
  const existing = load("user", null);
  if (!existing || existing.email !== email) {
    save("user", { email, name: email.split("@")[0] });
  }

  alert("Login correcto (demo).");
  window.location.href = "index.php";
});

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}
