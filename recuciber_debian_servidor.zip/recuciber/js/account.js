const userInfo = document.getElementById("userInfo");
const logoutBtn = document.getElementById("logoutBtn");

const user = load("user", null);

if (!user) {
  // Si no hay sesión, al login
  window.location.href = "login.php";
} else {
  userInfo.innerHTML = `
    <div class="summaryItem"><span>Nombre</span><span>${escapeHtml(user.name ?? "—")}</span></div>
    <div class="summaryItem"><span>Email</span><span>${escapeHtml(user.email ?? "—")}</span></div>
    <div class="summaryItem"><span>Usuario</span><span>${escapeHtml(user.usuario ?? user.username ?? "—")}</span></div>
  `;
}

logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("user");
  window.location.href = "index.php";
});

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
