const EUR = new Intl.NumberFormat("es-ES", { style: "currency", currency: "EUR" });

const products = [
  {
    id: "whey-2kg",
    name: "Whey Protein 2kg (Vainilla)",
    category: "proteina",
    desc: "Proteína de suero para recuperación y ganancia muscular.",
    price: 44.99,
    featured: true
  },
  {
    id: "iso-1kg",
    name: "Isolate 1kg (Chocolate)",
    category: "proteina",
    desc: "Alta pureza, ideal si buscas menos lactosa y más proteína por toma.",
    price: 39.90,
    featured: false
  },
  {
    id: "crea-mono",
    name: "Creatina Monohidrato 500g",
    category: "creatina",
    desc: "Mejora fuerza y rendimiento. 5g/día (recomendación general).",
    price: 19.95,
    featured: true
  },
  {
    id: "crea-caps",
    name: "Creatina en cápsulas (240 caps)",
    category: "creatina",
    desc: "Comodidad total para llevarla siempre encima.",
    price: 23.50,
    featured: false
  },
  {
    id: "prework",
    name: "Pre-Workout 300g",
    category: "preworkout",
    desc: "Energía y enfoque para tus entrenos (con cafeína).",
    price: 26.90,
    featured: true
  },
  {
    id: "omega3",
    name: "Omega 3 (120 perlas)",
    category: "salud",
    desc: "Apoyo general: salud cardiovascular y bienestar.",
    price: 14.75,
    featured: false
  },
];

let cart = load("cart", {});
let user = load("user", null);

const productsGrid = document.getElementById("productsGrid");
const searchInput = document.getElementById("searchInput");
const categorySelect = document.getElementById("categorySelect");
const sortSelect = document.getElementById("sortSelect");

const cartBtn = document.getElementById("cartBtn");
const cartDrawer = document.getElementById("cartDrawer");
const closeCart = document.getElementById("closeCart");
const cartItems = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const cartCount = document.getElementById("cartCount");
const clearCart = document.getElementById("clearCart");

const orderSummary = document.getElementById("orderSummary");
const orderForm = document.getElementById("orderForm");

const authBtn = document.getElementById("authBtn");
const authModal = document.getElementById("authModal");
const closeAuth = document.getElementById("closeAuth");
const tabLogin = document.getElementById("tabLogin");
const tabRegister = document.getElementById("tabRegister");
const authTitle = document.getElementById("authTitle");
const authForm = document.getElementById("authForm");
const authSubmit = document.getElementById("authSubmit");
const registerExtra = document.getElementById("registerExtra");
const authHint = document.getElementById("authHint");

document.getElementById("year").textContent = new Date().getFullYear();

init();

function init() {
  renderAuthButton();
  renderProducts();
  renderCart();
  renderOrderSummary();

  searchInput.addEventListener("input", renderProducts);
  categorySelect.addEventListener("change", renderProducts);
  sortSelect.addEventListener("change", renderProducts);

  cartBtn.addEventListener("click", () => openDrawer(true));
  closeCart.addEventListener("click", () => openDrawer(false));
  document.getElementById("goCheckout").addEventListener("click", () => openDrawer(false));
  clearCart.addEventListener("click", () => {
    cart = {};
    save("cart", cart);
    renderCart();
    renderOrderSummary();
  });

  authBtn.addEventListener("click", () => openAuth(true));
  closeAuth.addEventListener("click", () => openAuth(false));
  authModal.addEventListener("click", (e) => {
    if (e.target?.dataset?.close === "true") openAuth(false);
  });

  tabLogin.addEventListener("click", () => setAuthMode("login"));
  tabRegister.addEventListener("click", () => setAuthMode("register"));

  authForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("authEmail").value.trim();
    const pass = document.getElementById("authPass").value;
    const name = document.getElementById("authName").value.trim();

    const mode = authForm.dataset.mode || "login";
    if (mode === "register" && !name) {
      alert("En registro, pon tu nombre.");
      return;
    }

    user = { email, name: name || email.split("@")[0] };
    save("user", user);
    renderAuthButton();
    openAuth(false);
  });

  orderForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const items = cartToArray();
    if (items.length === 0) {
      alert("Tu carrito está vacío. Añade productos antes de confirmar.");
      return;
    }

    const formData = new FormData(orderForm);
    const payload = Object.fromEntries(formData.entries());

    // "mejor nota": validar + mostrar resumen
    const total = calcTotal();
    const msg =
      `Pedido confirmado (DEMO)\n\n` +
      `Cliente: ${payload.fullName}\nEmail: ${payload.email}\nTel: ${payload.phone}\n` +
      `Entrega: ${payload.delivery}\nPago: ${payload.payment}\n` +
      `Productos: ${items.map(i => `${i.name} x${i.qty}`).join(", ")}\n` +
      `TOTAL: ${EUR.format(total)}\n\n` +
      `Se ha generado un "recibo" en pantalla (demo).`;

    alert(msg);

    // opcional: limpiar carrito al confirmar
    cart = {};
    save("cart", cart);
    renderCart();
    renderOrderSummary();
    orderForm.reset();
  });
}

function renderAuthButton() {
  if (user) {
    authBtn.textContent = `Hola, ${user.name} (Salir)`;
    authBtn.classList.add("btn--ghost");
    authBtn.classList.remove("btn--primary");

    authBtn.onclick = () => {
      // logout
      user = null;
      save("user", user);
      authBtn.onclick = () => openAuth(true);
      renderAuthButton();
    };
  } else {
    authBtn.textContent = "Login / Registrarse";
    authBtn.classList.add("btn--primary");
    authBtn.classList.remove("btn--ghost");
    authBtn.onclick = () => openAuth(true);
  }
}

function renderProducts() {
  const q = searchInput.value.trim().toLowerCase();
  const cat = categorySelect.value;
  const sort = sortSelect.value;

  let list = products.filter(p => {
    const matchesQ = !q || (p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q));
    const matchesCat = (cat === "all") || (p.category === cat);
    return matchesQ && matchesCat;
  });

  list = sortProducts(list, sort);

  productsGrid.innerHTML = list.map(p => productCard(p)).join("");
  list.forEach(p => {
    const addBtn = document.getElementById(`add-${p.id}`);
    const qtyInput = document.getElementById(`qty-${p.id}`);

    addBtn.addEventListener("click", () => {
      const qty = clamp(parseInt(qtyInput.value || "1", 10), 1, 99);
      addToCart(p.id, qty);
      qtyInput.value = "1";
      openDrawer(true);
    });
  });
}

function productCard(p) {
  const catLabel = {
    proteina: "Proteína",
    creatina: "Creatina",
    preworkout: "Pre-entreno",
    salud: "Salud"
  }[p.category] || "Producto";

  return `
    <article class="card">
      <div class="card__img">
        <span class="tag">${catLabel}</span>
        <span class="price">${EUR.format(p.price)}</span>
      </div>
      <div class="card__body">
        <h3>${escapeHtml(p.name)}</h3>
        <p>${escapeHtml(p.desc)}</p>
      </div>
      <div class="card__foot">
        <input class="qty" id="qty-${p.id}" type="number" min="1" max="99" value="1" aria-label="Cantidad" />
        <button class="btn btn--primary" id="add-${p.id}">Añadir</button>
      </div>
    </article>
  `;
}

function sortProducts(list, mode) {
  const copy = [...list];
  if (mode === "featured") {
    return copy.sort((a, b) => Number(b.featured) - Number(a.featured));
  }
  if (mode === "priceAsc") return copy.sort((a, b) => a.price - b.price);
  if (mode === "priceDesc") return copy.sort((a, b) => b.price - a.price);
  if (mode === "nameAsc") return copy.sort((a, b) => a.name.localeCompare(b.name, "es"));
  return copy;
}

function openDrawer(open) {
  cartDrawer.classList.toggle("isOpen", open);
  cartDrawer.setAttribute("aria-hidden", open ? "false" : "true");
}

function openAuth(open) {
  authModal.classList.toggle("isOpen", open);
  authModal.setAttribute("aria-hidden", open ? "false" : "true");
  if (open) setAuthMode("login");
}

function setAuthMode(mode) {
  authForm.dataset.mode = mode;
  const isLogin = mode === "login";

  tabLogin.classList.toggle("tab--active", isLogin);
  tabRegister.classList.toggle("tab--active", !isLogin);

  authTitle.textContent = isLogin ? "Login" : "Registrarse";
  authSubmit.textContent = isLogin ? "Entrar" : "Crear cuenta";
  registerExtra.hidden = isLogin;

  authHint.textContent = isLogin
    ? "Demo: al entrar se guarda el usuario en localStorage."
    : "Demo: al registrarte se guarda el usuario en localStorage.";
}

function addToCart(productId, qty) {
  cart[productId] = (cart[productId] || 0) + qty;
  save("cart", cart);
  renderCart();
  renderOrderSummary();
}

function removeOne(productId) {
  if (!cart[productId]) return;
  cart[productId] -= 1;
  if (cart[productId] <= 0) delete cart[productId];
  save("cart", cart);
  renderCart();
  renderOrderSummary();
}

function addOne(productId) {
  cart[productId] = (cart[productId] || 0) + 1;
  save("cart", cart);
  renderCart();
  renderOrderSummary();
}

function renderCart() {
  const items = cartToArray();
  const count = items.reduce((acc, i) => acc + i.qty, 0);
  cartCount.textContent = String(count);

  if (items.length === 0) {
    cartItems.innerHTML = `<p class="muted">Tu carrito está vacío.</p>`;
    cartTotal.textContent = EUR.format(0);
    return;
  }

  cartItems.innerHTML = items.map(i => `
    <div class="cartItem">
      <div>
        <strong>${escapeHtml(i.name)}</strong>
        <div><small>${EUR.format(i.price)} • Subtotal: ${EUR.format(i.price * i.qty)}</small></div>
      </div>
      <div class="cartItem__actions">
        <button class="stepBtn" data-dec="${i.id}" aria-label="Quitar uno">−</button>
        <strong>${i.qty}</strong>
        <button class="stepBtn" data-inc="${i.id}" aria-label="Añadir uno">+</button>
      </div>
    </div>
  `).join("");

  cartItems.querySelectorAll("[data-dec]").forEach(btn => {
    btn.addEventListener("click", () => removeOne(btn.dataset.dec));
  });
  cartItems.querySelectorAll("[data-inc]").forEach(btn => {
    btn.addEventListener("click", () => addOne(btn.dataset.inc));
  });

  cartTotal.textContent = EUR.format(calcTotal());
}

function renderOrderSummary() {
  const items = cartToArray();
  if (items.length === 0) {
    orderSummary.innerHTML = `<p class="muted">Añade productos al carrito para ver el resumen aquí.</p>`;
    return;
  }

  orderSummary.innerHTML = `
    ${items.map(i => `
      <div class="summaryItem">
        <span>${escapeHtml(i.name)} <small>×${i.qty}</small></span>
        <span>${EUR.format(i.price * i.qty)}</span>
      </div>
    `).join("")}
    <div class="summaryTotal">
      <span>Total</span>
      <strong>${EUR.format(calcTotal())}</strong>
    </div>
  `;
}

function cartToArray() {
  return Object.entries(cart).map(([id, qty]) => {
    const p = products.find(x => x.id === id);
    return { id, qty, name: p?.name ?? id, price: p?.price ?? 0 };
  });
}

function calcTotal() {
  return cartToArray().reduce((acc, i) => acc + (i.price * i.qty), 0);
}

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, isNaN(n) ? min : n));
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
