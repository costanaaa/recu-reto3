const registerForm = document.getElementById("registerForm");

registerForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const pass = document.getElementById("pass").value;

  if (!name || !email || !pass) return;

  // Demo: guardar usuario
  save("user", { name, email });

  alert("Cuenta creada (demo). Ahora inicia sesión.");
  window.location.href = "login.php";
});

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
