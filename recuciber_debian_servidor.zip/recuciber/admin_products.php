<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>PowerSupps | Añadir producto</title>
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="css/register.css" />
</head>
<body>
<?php
session_start();
$msg = "";
$err = "";
include_once 'persistence/MySQLPDO.class.php';
include_once 'entity/Producto.class.php';
include_once 'entity/Usuario.class.php';
if (!isset($_SESSION["usuario"]) || $_SESSION["usuario"]["rol"] !== "admin") {
  header("Location: index.php");
  exit;
}

MySQLPDO::connect();
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function uploadImageToImg(&$err){
  if (!isset($_FILES["imagen"]) || $_FILES["imagen"]["error"] === UPLOAD_ERR_NO_FILE) {
    $err = "No se ha seleccionado imagen.";
    return null;
  }
  if ($_FILES["imagen"]["error"] !== UPLOAD_ERR_OK) {
    $err = "Error al subir la imagen. Código: " . $_FILES["imagen"]["error"];
    return null;
  }

  if ($_FILES["imagen"]["size"] > 8 * 1024 * 1024) {
    $err = "La imagen supera 8MB.";
    return null;
  }

  $allowed = ["jpg","jpeg","png","webp"];
  $name = $_FILES["imagen"]["name"];
  $tmp  = $_FILES["imagen"]["tmp_name"];
  $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));

  if (!in_array($ext, $allowed, true)) {
    $err = "Formato no permitido. Usa JPG, PNG o WEBP.";
    return null;
  }

  $dirFs  = __DIR__ . "/img/"; // <-- RUTA REAL EN DISCO
  $dirWeb = "img/";            // <-- RUTA PARA EL <img src="">

  if (!is_dir($dirFs) && !mkdir($dirFs, 0755, true)) {
    $err = "No se pudo crear la carpeta img/.";
    return null;
  }

  $safeName = time() . "_" . bin2hex(random_bytes(6)) . "." . $ext;
  $destFs   = $dirFs . $safeName;
  $destWeb  = $dirWeb . $safeName;

  if (!move_uploaded_file($tmp, $destFs)) {
    $err = "No se pudo guardar la imagen en img/.";
    return null;
  }

  chmod($destFs, 0644);
  return $destWeb;
}

/* --------- ADD PRODUCT --------- */
if (isset($_POST["btn_add"])) {
    $nombre = trim($_POST['nombre'] ?? "");
    $descripcion = trim($_POST['descripcion'] ?? "");
    $precio = (float)($_POST['precio'] ?? 0);
    $categoria = trim($_POST['categoria'] ?? "");

    $rutaImagen = uploadImageToImg($err);  // <-- AQUÍ se sube

    if ($nombre === "" || $descripcion === "" || $precio <= 0 || $categoria === "") {
        $err = "Rellena nombre, descripción, precio y categoría.";
    } elseif ($rutaImagen === null) {
        if ($err === "") $err = "No se ha podido subir la imagen.";
    } else {
        $objetoProducto = new Producto();
        $objetoProducto->setNombrep($nombre);
        $objetoProducto->setDescripcionp($descripcion);
        $objetoProducto->setPreciop($precio);
        $objetoProducto->setImagenp($rutaImagen); // <-- img/archivo.jpg
        $objetoProducto->setCategoria($categoria);

        $resultado = MySQLPDO::nuevoProducto($objetoProducto);

        if ($resultado != 0) {
            echo '<script>
                alert("Producto añadido correctamente");
                window.location.href = "admin_products.php";
            </script>';
            exit;
        } else {
            $err = "No se pudo insertar el producto.";
        }
    }
}

?>
<header class="header">
  <a class="brand" href="index.php">
    <span class="brand__logo">PS</span>
    <span class="brand__text">
      <strong>PowerSupps</strong>
      <small>Admin · Añadir producto</small>
    </span>
  </a>

  <div class="header__actions">
    <a class="btn btn--ghost" href="index.php">← Volver a la tienda</a>
  </div>
</header>

<main class="authPage">
  <section class="authCard authCard--narrow">
    <h2>Añadir producto</h2>
    <p class="muted">Solo administradores (rol=admin).</p>

    <?php if ($err): ?>
      <p style="color:#f87171; font-size:13px; margin:10px 0;">❌ <?= h($err) ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="form authForm">
      <table>

        <tr>
          <td><p>Nombre:</p></td>
          <td>
            <input type="text" name="nombre" required placeholder="Ej: Whey Protein 2kg">
          </td>
        </tr>

        <tr>
          <td><p>Descripción:</p></td>
          <td>
            <textarea name="descripcion" rows="4" required
              style="width:100%; border-radius:14px; border:1px solid var(--border);
                     background:rgba(255,255,255,.03); color:var(--text);
                     padding:10px 12px; outline:none;"
              placeholder="Describe el producto..."></textarea>
          </td>
        </tr>

        <tr>
          <td><p>Precio (€):</p></td>
          <td>
            <input type="number" step="0.01" min="0" name="precio" required>
          </td>
        </tr>

        <tr>
          <td><p>Categoría:</p></td>
          <td>
            <select name="categoria" required
              style="width:100%; border-radius:14px; border:1px solid var(--border);
                     background:rgba(255,255,255,.03); color:var(--text);
                     padding:10px 12px; outline:none;">
              <option value="Proteína">Proteína</option>
              <option value="Creatina">Creatina</option>
              <option value="Pre-entreno">Pre-entreno</option>
              <option value="Salud">Salud</option>
            </select>
          </td>
        </tr>

        <tr>
          <td><p>Imagen:</p></td>
          <td>
            <input type="file" name="imagen" accept=".jpg,.jpeg,.png,.webp,image/*" required>
            <p class="tiny muted" style="margin-top:6px;">
              Formatos: JPG/PNG/WEBP · 8MB maximo
            </p>
          </td>
        </tr>

        <tr>
          <td colspan="2">
            <input type="submit" name="btn_add" value="AÑADIR PRODUCTO">
          </td>
        </tr>

      </table>
    </form>

  </section>
</main>

</body>
</html>
