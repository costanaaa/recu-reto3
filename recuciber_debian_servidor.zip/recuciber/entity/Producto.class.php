<?php
    class Producto{
        private $idp;
        private $nombrep;
        private $descripcionp;
        private $preciop;
        private $imagenp;
        private $categoria;

        /**
         * Get the value of idp
         */ 
        public function getIdp()
        {
                return $this->idp;
        }

        /**
         * Set the value of idp
         *
         * @return  self
         */ 
        public function setIdp($idp)
        {
                $this->idp = $idp;

                return $this;
        }

        /**
         * Get the value of nombrep
         */ 
        public function getNombrep()
        {
                return $this->nombrep;
        }

        /**
         * Set the value of nombrep
         *
         * @return  self
         */ 
        public function setNombrep($nombrep)
        {
                $this->nombrep = $nombrep;

                return $this;
        }

        /**
         * Get the value of descripcionp
         */ 
        public function getDescripcionp()
        {
                return $this->descripcionp;
        }

        /**
         * Set the value of descripcionp
         *
         * @return  self
         */ 
        public function setDescripcionp($descripcionp)
        {
                $this->descripcionp = $descripcionp;

                return $this;
        }

        /**
         * Get the value of preciop
         */ 
        public function getPreciop()
        {
                return $this->preciop;
        }

        /**
         * Set the value of preciop
         *
         * @return  self
         */ 
        public function setPreciop($preciop)
        {
                $this->preciop = $preciop;

                return $this;
        }

        /**
         * Get the value of imagenp
         */ 
        public function getImagenp()
        {
                return $this->imagenp;
        }

        /**
         * Set the value of imagenp
         *
         * @return  self
         */ 
        public function setImagenp($imagenp)
        {
                $this->imagenp = $imagenp;

                return $this;
        }

        /**
         * Get the value of categoria
         */ 
        public function getCategoria()
        {
                return $this->categoria;
        }

        /**
         * Set the value of categoria
         *
         * @return  self
         */ 
        public function setCategoria($categoria)
        {
                $this->categoria = $categoria;

                return $this;
        }
    }
?>