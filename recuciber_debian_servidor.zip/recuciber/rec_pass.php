<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>PowerSupps | Cambio Contraseña</title>
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="css/register.css" />
</head>
<body>
  <?php
    session_start();
    $nombreUsuario = "";
    if (isset($_GET['user'])) {
        $nombreUsuario = $_GET['user'];
    }
  ?>
  <header class="header">
    <a class="brand" href="index.php">
      <span class="brand__logo">PS</span>
      <span class="brand__text">
        <strong>PowerSupps</strong>
        <small>Cambio Contraseña</small>
      </span>
    </a>

    <div class="header__actions">
      <a class="userBtn" href="account.php" title="Mi cuenta">
        👤
      </a>
    </div>
  </header>
  <?php
    include_once 'entity/Usuario.class.php';
    include_once 'persistence/MySQLPDO.class.php';
    if(isset($_POST['btn_rec'])){
      $password = $_POST['password'];
      $rep_password = $_POST['rep_password'];
      if($password != $rep_password){
        echo '<script language="javascript">alert ("ERROR: Las contraseñas no coinciden")</script>';
      } else {
        $objetoUsuario = new Usuario();
        $objetoUsuario->setPass($password);
        $objetoUsuario->setId($_SESSION['iduser']);
        MySQLPDO::connect();
        $resultado = MySQLPDO::cambiarPassword($objetoUsuario);
        if($resultado != 0){
          echo '<script language="javascript">alert ("La contraseña se ha cambiado correctamente");
          window.location.href = "account.php"; </script>';
        }
      }
    }
  ?>
  <main class="authPage">
    <section class="authCard authCard--narrow">
      <h2>Cambiar Contraseña</h2>
      <p class="muted">
        ¿Quieres cambiar de contraseña, <strong><?php echo htmlspecialchars($nombreUsuario); ?></strong>?
      </p>

      <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post" id="registerForm" class="form authForm">
        <table>
          <tr>
            <td><p>Contrase&ntilde;a:</p></td>
            <td>
              <input type="password" name="password" id="pass" maxlength="40" minlength="6" required="required" placeholder="••••••••">
            </td>
          </tr>
          <tr>
            <td><p>Repetir Contrase&ntilde;a:</p></td>
            <td>
              <input type="password" name="rep_password" id="rep_pass" maxlength="40" minlength="6" required="required" placeholder="••••••••">
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <input type="submit" name="btn_rec" value="CAMBIAR CONTRASEÑA">
            </td>
          </tr>
        </table>
      </form>
      </form>
    </section>
  </main>
</body>
</html>
