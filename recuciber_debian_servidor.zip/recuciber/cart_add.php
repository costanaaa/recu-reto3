<?php
session_start();

$id = (int)($_POST["id"] ?? 0);
$qty = (int)($_POST["qty"] ?? 1);
if ($id <= 0) { header("Location: index.php"); exit; }
if ($qty < 1) $qty = 1;

if (!isset($_SESSION["carrito"])) $_SESSION["carrito"] = [];
if (!isset($_SESSION["carrito"][$id])) $_SESSION["carrito"][$id] = 0;

$_SESSION["carrito"][$id] += $qty;

header("Location: index.php");
exit;
?>