<?php
session_start();
include_once 'persistence/MySQLPDO.class.php';
MySQLPDO::connect();

$carrito = $_SESSION["carrito"] ?? [];
$items = [];
$total = 0;

if ($carrito) {
  $ids = array_keys($carrito);
  $in  = implode(",", array_fill(0, count($ids), "?"));
  $prods = MySQLPDO::select("SELECT * FROM producto WHERE id IN ($in)", $ids);

  foreach ($prods as $p) {
    $id = (int)$p["id"];
    $qty = (int)$carrito[$id];
    $sub = $qty * (float)$p["precio"];
    $total += $sub;
    $items[] = ["p"=>$p,"qty"=>$qty,"sub"=>$sub];
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Carrito</title>
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<header class="header">
  <a class="brand" href="index.php">
    <span class="brand__logo">PS</span>
    <span class="brand__text"><strong>PowerSupps</strong><small>Carrito</small></span>
  </a>
  <div class="header__actions">
    <a class="btn btn--ghost" href="index.php">← Seguir comprando</a>
    <a class="btn btn--ghost" href="cart_clear.php">Vaciar</a>
  </div>
</header>

<main class="container section">
  <div class="summaryBox">
    <h3>Tu carrito</h3>

    <?php if (!$items): ?>
      <p class="muted">Carrito vacío.</p>
    <?php else: ?>
      <?php foreach($items as $it): $p=$it["p"]; ?>
        <div class="cartItem">
          <div>
            <strong><?= htmlspecialchars($p["nombre"]) ?></strong><br>
            <small><?= htmlspecialchars($p["categoria"]) ?></small><br>
            <small class="muted">Precio: <?= htmlspecialchars($p["precio"]) ?>€ · Cantidad: <?= (int)$it["qty"] ?></small>
          </div>
          <div><strong><?= number_format($it["sub"], 2) ?>€</strong></div>
        </div>
      <?php endforeach; ?>

      <div class="summaryTotal">
        <strong>Total</strong>
        <strong><?= number_format($total, 2) ?>€</strong>
      </div>
    <?php endif; ?>
  </div>
</main>
</body>
</html>
