<?php
class MySQLPDO {
    private static $host = "localhost"; //o la IP del servidor de BBBDD remoto
    private static $database = "tienda";
    private static $username = "admin_ciber";
    private static $password = "ByronLove$";
    private static $base;
    
    public static function connect() {
        if (MySQLPDO::$base != null) {
            MySQLPDO::$base = null;
        }
        try {
            $dsn = "mysql:host=" . MySQLPDO::$host . ";dbname=" . MySQLPDO::$database;
            MySQLPDO::$base = new PDO($dsn, MySQLPDO::$username, MySQLPDO::$password);
            MySQLPDO::$base->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return MySQLPDO::$base;
        } catch (Exception $e) {
            die ("Error connecting: {$e->getMessage()}");
        }
    }
    
    //ejecuta sentencias INSERT, UPDATE y DELETE
    public static function exec($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->rowCount();
        return $result; //devuelve el n� de filas afectadas por la sentencia
    }
    
    //ejecuta sentencias SELECT
    public static function select($sql, $params) {
        $stmt = MySQLPDO::$base->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll();
        return $result; //devuelve el conjunto de datos de la consulta
    }
    public static function insertUsuario($objetoUsuario){
        $sql = "INSERT INTO usuario(nombre,apellidos,email,user,password) VALUES ( ? , ? , ? , ? , ? )";
        $params= array(
            $objetoUsuario->getNombre(),
            $objetoUsuario->getApellido(),
            $objetoUsuario->getEmail(),
            $objetoUsuario->getUser(),
            $objetoUsuario->getPass()
        );
        $resultado = MySQLPDO::exec($sql,$params);
        return $resultado;
    }
    public static function loginUsuario($objetoUsuario){
        $sql = "SELECT * FROM usuario WHERE email = ? AND password = ?";
        $params= array(
            $objetoUsuario->getEmail(),
            $objetoUsuario->getPass()
        );
        $resultado = MySQLPDO::select($sql,$params);
        if (sizeof($resultado) != 0){
            extract ($resultado[0]);
            $objetoUsuario = new Usuario();
            $objetoUsuario->setId($id);
            $objetoUsuario->setUser($user);
            $objetoUsuario->setRol($rol);
            return $objetoUsuario;
        } else {
            return null;
        }
    }
    public static function getUsuarioById($id){
    $sql = "SELECT * FROM usuario WHERE id = ?";
    $params = array($id);
    $resultado = MySQLPDO::select($sql, $params);
    if (is_array($resultado) && count($resultado) > 0) {
        return $resultado[0];
    }
    return null;
    }
    public static function usuarioNombre($id){
    $sql = "SELECT user FROM usuario WHERE id = ?";
    $params = array($id);
    $resultado = MySQLPDO::select($sql, $params);
    if (is_array($resultado) && count($resultado) > 0) {
        return $resultado[0];
    }
    return null;
    }
    public static function cambiarPassword($objetoUsuario){
        $sql = "UPDATE usuario SET password = ? WHERE id = ?";
        $params= array(
            $objetoUsuario->getPass(),
            $objetoUsuario->getId()
        );
        $resultado = MySQLPDO::exec($sql,$params);
        return $resultado;
    }
    public static function nuevoProducto($objetoProducto){
        $sql = "INSERT INTO producto(nombre,descripcion,precio,imagen,categoria) VALUES ( ? , ? , ? , ? , ? )";
        $params= array(
            $objetoProducto->getNombrep(),
            $objetoProducto->getDescripcionp(),
            $objetoProducto->getPreciop(),
            $objetoProducto->getImagenp(),
            $objetoProducto->getCategoria()
        );
        $resultado = MySQLPDO::exec($sql,$params);
        return $resultado;
    }
}
?>
