<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>PowerSupps | Registro</title>
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="css/register.css" />
</head>
<body>

  <header class="header">
    <a class="brand" href="index.php">
      <span class="brand__logo">PS</span>
      <span class="brand__text">
        <strong>PowerSupps</strong>
        <small>Registro</small>
      </span>
    </a>

    <div class="header__actions">
      <a class="btn btn--ghost" href="login.php">← Volver al login</a>
    </div>
  </header>
  <?php
    include_once 'entity/Usuario.class.php';
    include_once 'persistence/MySQLPDO.class.php';
    if(isset($_POST['btn_usuario'])){
      $nombre = $_POST['nombre'];
      $apellido = $_POST['apellido'];
      $usuario = $_POST['usuario'];
      $email = $_POST['email'];
      $password = $_POST['password'];
      $rep_password = $_POST['rep_password'];
      if($password != $rep_password){
        echo '<script language="javascript">alert ("ERROR: Las contraseñas no coinciden")</script>';
      } else {
        $objetoUsuario = new Usuario();
        $objetoUsuario->setNombre($nombre);
        $objetoUsuario->setApellido($apellido);
        $objetoUsuario->setUser($usuario);
        $objetoUsuario->setEmail($email);
        $objetoUsuario->setPass($password);

        MySQLPDO::connect();
        $resultado = MySQLPDO::insertUsuario($objetoUsuario);
        if($resultado != 0){
          echo '<script language="javascript">alert ("El usuario ha '. $usuario .' sido registrado correctamente");
          window.location.href = "login.php"; </script>';
        }
      }
    }
        ?>
  <main class="authPage">
    <section class="authCard authCard--narrow">
      <h2>Registrar Usuario</h2>
      <p class="muted">Crea tu cuenta (demo).</p>
      <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post" id="registerForm" class="form authForm">
        <table>
          <tr>
            <td><p>Nombre:</p></td>
            <td>
              <input type="text" name="nombre" id="name" maxlength="20" required="required" placeholder="Tu nombre">
            </td>
          </tr>

          <tr>
            <td><p>Apellidos:</p></td>
            <td>
              <input type="text" name="apellido" id="apellido" maxlength="40" required="required" placeholder="Tus 2 primeros apellidos">
            </td>
          </tr>

          <tr>
            <td><p>Usuario:</p></td>
            <td>
              <input type="text" name="usuario" id="user" maxlength="20" required="required" placeholder="Nombre de usuario">
            </td>
          </tr>

          <tr>
            <td><p>Email:</p></td>
            <td>
              <input type="email" name="email" id="email" maxlength="70" required="required" placeholder="correo@dominio.com">
            </td>
          </tr>

          <tr>
            <td><p>Contrase&ntilde;a:</p></td>
            <td>
              <input type="password" name="password" id="pass" maxlength="40" minlength="6" required="required" placeholder="••••••••">
            </td>
          </tr>

          <tr>
            <td><p>Repetir Contrase&ntilde;a:</p></td>
            <td>
              <input type="password" name="rep_password" id="rep_pass" maxlength="40" minlength="6" required="required" placeholder="••••••••">
            </td>
          </tr>
         <tr>
            <td colspan="2">
              <input type="checkbox" id="cbox1" required="required">
              Acepto los términos y condiciones de la
              <a target="_blank" href="pdp.pdf">Pol&iacute;tica de Privacidad</a>
              <br><br>
            </td>
          </tr>

          <tr>
            <td colspan="2">
              <input type="submit" name="btn_usuario" value="CREAR CUENTA">
            </td>
          </tr>
          <tr>
            <td colspan="2" style="padding-top:10px;">
              ¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
            </td>
          </tr>
        </table>
      </form>
      </form>
    </section>
  </main>
</body>
</html>
